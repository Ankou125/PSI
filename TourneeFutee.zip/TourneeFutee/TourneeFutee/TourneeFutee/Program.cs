﻿namespace TourneeFutee
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // TODO : faire vos propres tests ici
        }
    }
}
